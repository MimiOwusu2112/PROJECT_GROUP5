#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <iostream>
#include <chrono>
#include <thread>

using namespace std;

class Elevator {
private:
    int currentFloor;
    int desiredFloor;
    int numberOfFloors;
    bool doorOpen;
public:
    Elevator(int floors): currentFloor(1), numberOfFloors(floors), doorOpen(false) {}
    void openDoor() {
        cout << "Door opening..." << endl;
        this_thread::sleep_for(chrono::seconds(2));
        doorOpen = true;
        cout << "Door opened." << endl;
    }
    void closeDoor() {
        cout << "Door closing..." << endl;
        this_thread::sleep_for(chrono::seconds(2));
        doorOpen = false;
        cout << "Door closed." << endl;
    }
    void moveToFloor(int floor) {
        if (floor < 1 || floor > numberOfFloors) {
            cout << "This building does not have a " << floor << "th floor." << endl;
            return;
        }
        desiredFloor = floor;
        if (currentFloor == desiredFloor) {
            cout << "You are already on floor " << currentFloor << "." << endl;
            return;
        }
        cout << "Going ";
        if (desiredFloor > currentFloor) {
            cout << "up..." << endl;
            while (currentFloor < desiredFloor) {
                currentFloor++;
                cout << "Now on floor " << currentFloor << "." << endl;
            }
        } else {
            cout << "down..." << endl;
            while (currentFloor > desiredFloor) {
                currentFloor--;
                cout << "Now on floor " << currentFloor << "." << endl;
            }
        }
        cout << "You have arrived at floor " << currentFloor << "." << endl;
    }
};

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    // create the GUI elements
    QLabel *titleLabel = new QLabel("Elevator");
    titleLabel->setAlignment(Qt::AlignCenter);

    QLabel *floorLabel = new QLabel("Floor:");
    QLineEdit *floorLineEdit = new QLineEdit;
    floorLineEdit->setPlaceholderText("Enter the desired floor");

    QPushButton *moveButton = new QPushButton("Move");
    moveButton->setFixedSize(200, 50);

    // create the layout and add the elements to it
    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(titleLabel);
    layout->addWidget(floorLabel);
    layout->addWidget(floorLineEdit);
    layout->addWidget(moveButton);

    // create the Elevator object
    Elevator elevator(5);

    // connect the move button to the Elevator object
    QObject::connect(moveButton, &QPushButton::clicked, [&](){
        int desiredFloor = floorLineEdit->text().toInt();
        elevator.moveToFloor(desiredFloor);
    });

    // create the main window and set the layout
    QWidget window;
    window.setLayout(layout);
    window.setWindowTitle("Elevator");
    window.show();

    return app.exec();
}

#include <iostream>
#include <chrono>
#include <thread>
using namespace std;

class Elevator {
private:
    int currentFloor;
    int desiredFloor;
    int numberOfFloors;
    bool doorOpen;
public:
    Elevator(int floors): currentFloor(1), numberOfFloors(floors), doorOpen(false) {}
    void openDoor() {
        cout << "Door opening..." << endl;
        this_thread::sleep_for(chrono::seconds(2));
        doorOpen = true;
        cout << "Door opened." << endl;
    }
    void closeDoor() {
        cout << "Door closing..." << endl;
        this_thread::sleep_for(chrono::seconds(2));
        doorOpen = false;
        cout << "Door closed." << endl;
    }
    void moveToFloor(int floor) {
        if (floor < 1 || floor > numberOfFloors) {
            cout << "This building does not have a " << floor << "th floor." << endl;
            return;
        }
        desiredFloor = floor;
        if (currentFloor == desiredFloor) {
            cout << "You are already on floor " << currentFloor << "." << endl;
            return;
        }
        cout << "Going ";
        if (desiredFloor > currentFloor) {
            cout << "up..." << endl;
            while (currentFloor < desiredFloor) {
                currentFloor++;
                cout << "Now on floor " << currentFloor << "." << endl;
            }
        } else {
            cout << "down..." << endl;
            while (currentFloor > desiredFloor) {
                currentFloor--;
                cout << "Now on floor " << currentFloor << "." << endl;
            }
        }
        cout << "You have arrived at floor " << currentFloor << "." << endl;
    }
    void operate() {
        char choice;
        do {
            cout << "You are currently on floor " << currentFloor << "." << endl;
            cout << "There are " << numberOfFloors << " floors in this building." << endl;
            cout << "Which floor would you like to go to? ";
            cin >> desiredFloor;
            cout << endl;
            moveToFloor(desiredFloor);
            cout << "Do you want to move to another floor? (y/n) ";
            cin >> choice;
            cout << endl;
        } while (choice == 'y');
        openDoor();
        cout << "Thanks for using the elevator!" << endl;
        closeDoor();
    }
};

int main() {
    Elevator elevator(5);
    elevator.operate();
    return 0;
}
